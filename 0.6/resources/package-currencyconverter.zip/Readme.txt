

The following artifacts are included in this package:
    API currencyconverter v.1.0 => APIImplementation currencyconverter v1.0
    Connector foreignexchange v1.0
