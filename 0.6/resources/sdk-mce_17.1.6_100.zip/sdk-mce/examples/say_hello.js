"use strict";

var log4js = require('log4js');
var logger = log4js.getLogger();

module.exports = {

        metadata: () => (
        {
            "name": "say_hello",
            "properties": {
                "name": { "type": "string", "required": true }
            },
            "supportedActions": []
        }
    ),

    invoke: (conversation, done) => {
        const name = conversation.properties().name ? conversation.properties().name : '';
        conversation.reply({ text: 'Hello ' + name });

        // accessing OMCe custom code SDK via conversation.oracleMobile
        // See Calling OMCe APIs from Custom Code at
        //  http://www.oracle.com/pls/topic/lookup?ctx=en/cloud/paas/mobile-suite&id=MSUDG-GUID-27778194-E8A5-42B3-B587-02009731BD6D
        conversation.reply({ text: 'This reply has been produced by an API associated with MBE ' + conversation.oracleMobile.mbe.getMBE().name });

        conversation.transition();
        done();
    }
};