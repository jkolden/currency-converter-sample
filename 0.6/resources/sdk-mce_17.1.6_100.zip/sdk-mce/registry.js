'use strict';

module.exports = {
  components: {
    'say_hello': require('./examples/say_hello')
  }
};
