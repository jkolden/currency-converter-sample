

The following artifacts are included in this package:
    MobileBackend currencyConverterMBE v1.0
    API currencyconverter v.1.0 => APIImplementation currencyconverter v1.0
    API converterccs v.1.0 => APIImplementation converterccs v1.0.0
    Connector foreignexchange v1.0
    UserRealm Default v1.0
